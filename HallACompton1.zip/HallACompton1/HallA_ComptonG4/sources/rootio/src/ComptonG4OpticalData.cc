#include "ComptonG4OpticalData.hh"

ClassImp(ComptonG4OpticalData)
