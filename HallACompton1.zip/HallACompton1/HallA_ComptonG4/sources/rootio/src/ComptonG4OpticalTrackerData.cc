#include "ComptonG4OpticalTrackerData.hh"

ClassImp(ComptonG4OpticalTrackerData)
