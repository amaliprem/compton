#include "ComptonG4PrimaryData.hh"

ClassImp(ComptonG4PrimaryData)
