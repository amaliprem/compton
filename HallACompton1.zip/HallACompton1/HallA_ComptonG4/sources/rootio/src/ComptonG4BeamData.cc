#include "ComptonG4BeamData.hh"

ClassImp(ComptonG4BeamData)
