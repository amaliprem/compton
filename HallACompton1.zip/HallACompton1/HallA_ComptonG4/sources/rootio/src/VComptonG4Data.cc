#include "VComptonG4Data.hh"

ClassImp(VComptonG4Data)
