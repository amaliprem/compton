#include "ComptonG4Data.hh"

ClassImp(ComptonG4Data)
