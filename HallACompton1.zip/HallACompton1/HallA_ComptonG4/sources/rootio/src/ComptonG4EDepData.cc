#include "ComptonG4EDepData.hh"

ClassImp(ComptonG4EDepData)
