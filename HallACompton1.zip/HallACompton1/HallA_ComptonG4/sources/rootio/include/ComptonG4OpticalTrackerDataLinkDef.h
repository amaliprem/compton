#ifndef COMPTONG4OPTICALTRACKERDATALINKDEF_H
#define COMPTONG4OPTICALTRACKERDATALINKDEF_H
#ifdef __MAKECINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class ComptonG4OpticalTrackerData+;
#pragma link C++ class std::vector<ComptonG4OpticalTrackerData>+;
#pragma link C++ class std::vector<ComptonG4OpticalTrackerData*>+;

#endif
#endif
