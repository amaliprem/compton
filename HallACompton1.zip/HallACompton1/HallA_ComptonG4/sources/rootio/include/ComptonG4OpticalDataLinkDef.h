#ifndef COMPTONG4OPTICALDATALINKDEF_H
#define COMPTONG4OPTICALDATALINKDEF_H
#ifdef __MAKECINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class ComptonG4OpticalData+;
#pragma link C++ class std::vector<ComptonG4OpticalData>+;
#pragma link C++ class std::vector<ComptonG4OpticalData*>+;

#endif
#endif
