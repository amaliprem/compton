#ifndef COMPTONG4PRIMARYDATALINKDEF_H
#define COMPTONG4PRIMARYDATALINKDEF_H
#ifdef __MAKECINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class ComptonG4PrimaryData+;
#pragma link C++ class std::vector<ComptonG4PrimaryData>+;

#endif
#endif
