#ifndef COMPTONG4BEAMDATALINKDEF_H
#define COMPTONG4BEAMDATALINKDEF_H
#ifdef __MAKECINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class ComptonG4BeamData+;
#pragma link C++ class std::vector<ComptonG4BeamData>+;
#pragma link C++ class std::vector<ComptonG4BeamData*>+;

#endif
#endif
