#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class VComptonG4Data+;
#pragma link C++ class std::vector< VComptonG4Data >+;

#endif
