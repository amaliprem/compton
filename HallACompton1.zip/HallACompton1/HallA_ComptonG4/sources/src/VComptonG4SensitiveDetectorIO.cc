#include "VComptonG4SensitiveDetectorIO.hh"
#include <TBranch.h>
#include <TTree.h>

/*
 *
 */
VComptonG4SensitiveDetectorIO::VComptonG4SensitiveDetectorIO()
{
}

/*
 *
 */
VComptonG4SensitiveDetectorIO::~VComptonG4SensitiveDetectorIO()
{
}
