/*
 * ComptonG4PhotonDetectorHit.cc
 *
 *  Created on: May 23, 2013
 *      Author: Juan Carlos Cornejo <cornejo@jlab.org>
 */

#include "ComptonG4PhotonDetectorHit.hh"

G4Allocator<ComptonG4PhotonDetectorHit> ComptonG4PhotonDetectorHitAllocator;

ComptonG4PhotonDetectorHit::ComptonG4PhotonDetectorHit() :
  fEDep(0.0)
{
  // TODO Auto-generated constructor stub

}

ComptonG4PhotonDetectorHit::~ComptonG4PhotonDetectorHit() {
  // TODO Auto-generated destructor stub
}

void ComptonG4PhotonDetectorHit::Draw()
{

}

void ComptonG4PhotonDetectorHit::Print()
{

}

